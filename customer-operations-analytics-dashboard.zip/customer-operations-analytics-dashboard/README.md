# Customer Operations Analytics Dashboard

Portfolio project for customer-support and operational analytics.

## Objective
Analyze support-ticket data to identify trends, SLA bottlenecks, resolution-time patterns, and customer-satisfaction drivers.

## Workflow
Python/Pandas data loading and cleaning -> data validation -> EDA -> SQL KPI analysis -> Power BI dashboard -> business insights.

## KPIs
Total tickets, resolved/pending tickets, average resolution time, SLA compliance, customer satisfaction, and ticket volume by category/priority/product/channel.

## Tools
Python, Pandas, SQL, Excel, Power BI, Matplotlib.

## Repository
- `data/support_tickets.csv` — synthetic portfolio dataset
- `src/analysis.py` — cleaning, validation and EDA
- `sql/kpi_queries.sql` — KPI queries
- `outputs/` — generated analysis outputs

> Dataset is synthetic and intended for portfolio/demo purposes.
